empLogit <- function(x, eps = 1e-3) log((eps + x)/(1 - x+eps))

